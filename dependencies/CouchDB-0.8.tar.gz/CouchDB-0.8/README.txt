CouchDB Python Library
======================

This package provides a Python interface to CouchDB.

  <http://couchdb.org/>

Please see the files in the `doc` folder or browse the documentation online at:

  <http://packages.python.org/CouchDB/>
